import {html, render} from './node_modules/lit-html/lit-html.js'
import {towns} from './towns.js'

const searchBtn = document.querySelector('button')
searchBtn.addEventListener('click', search)

const townsListTemplate = (towns) => html `
<ul>
   ${towns.map(x => html`<li>${x}</li>`)}
</ul>
`
render(townsListTemplate(towns), document.querySelector('#towns'))

function search() {
   let counter = 0
   const searchInput = document.querySelector('#searchText')
   const townElements = document.querySelector('#towns ul').children
   
   for (const townEl of townElements) {
     
      if(townEl.textContent.includes(searchInput.value) ) {
         townEl.className = 'active'
         counter++
      }
   }
   document.querySelector('#result').textContent = `${counter} matches found`
}
